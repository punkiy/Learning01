package com.example.submisionawal_fundamental.UI

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.submisionawal_fundamental.databinding.FragmentFollowBinding


class FollowFragment : Fragment() {
    private var position:Int=0
    private var username:String?=null
    private lateinit var binding: FragmentFollowBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: UserAdapter
    private lateinit var progressBar:ProgressBar
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentFollowBinding.inflate(inflater,container,false)
        val recyclerView=binding.recyclerView
        adapter = UserAdapter { user->
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra(DetailActivity.EXTRA_USERNAME, user.login)
            startActivity(intent)
        }
        progressBar=binding.progressBarr
        recyclerView.layoutManager= LinearLayoutManager(requireContext())
        recyclerView.adapter=adapter
        return binding.root
    }
    companion object{
        const val ARG_POSITION="position"
        const val ARG_USERNAME="username"
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            position=it.getInt(ARG_POSITION)
            username=it.getString(ARG_USERNAME)
        }
        viewModel= ViewModelProvider(this).get(MainViewModel::class.java)
        if (position == 1) {
            viewModel.userFollowers.observe(viewLifecycleOwner, Observer { followers ->
                progressBar.visibility=View.GONE
                adapter.submitList(followers)
            })
        } else {
            viewModel.userFollowing.observe(viewLifecycleOwner, Observer { following ->
                progressBar.visibility=View.GONE
                adapter.submitList(following)
            })
        }
    }

}