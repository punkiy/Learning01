package com.example.submisionawal_fundamental.UI

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.submisionawal_fundamental.data.response.DetailUserResponse
import com.example.submisionawal_fundamental.data.response.GithubResponse
import com.example.submisionawal_fundamental.data.response.ItemsItem
import com.example.submisionawal_fundamental.data.retrofit.ApiConfig
import retrofit2.*

class MainViewModel : ViewModel() {

    private val _listUser=MutableLiveData<List<ItemsItem>>()
    val listUser:LiveData<List<ItemsItem>> =_listUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _userDetail=MutableLiveData<DetailUserResponse?>()
    val userDetail:LiveData<DetailUserResponse?> = _userDetail

    private val _userFollowers=MutableLiveData<List<ItemsItem>?>()
    val userFollowers:LiveData<List<ItemsItem>?> = _userFollowers

    private val _userFollowing=MutableLiveData<List<ItemsItem>?>()
    val userFollowing:LiveData<List<ItemsItem>?> = _userFollowing

    fun getFollowers(username: String) {
        _isLoading.postValue(true)
        val client = ApiConfig.getService().getFollowers(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                if (response.isSuccessful) {
                    val followers = response.body()
                    _userFollowers.postValue(followers)
                }
                _isLoading.postValue(false)
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.postValue(false)
            }
        })
    }

    fun getFollowing(username: String) {
        _isLoading.postValue(true)
        val client = ApiConfig.getService().getFollowing(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                if (response.isSuccessful) {
                    val following = response.body()
                    _userFollowing.postValue(following)
                }
                _isLoading.postValue(false)
            }
            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.postValue(false)
            }
        })
    }
    fun getUserDetail(username:String){
        _isLoading.postValue(true)
        val client=ApiConfig.getService().getDetailUser(username)
        client.enqueue(object :Callback<DetailUserResponse>{
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>
            ) {
                _isLoading.postValue(false)
                if (response.isSuccessful){
                    val detailResponse=response.body()
                    _userDetail.postValue(detailResponse)
                }
            }
            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isLoading.postValue(false)
            }
        })
    }

    fun getUsers(login:String){
        _isLoading.postValue(true)
        val client=ApiConfig.getService().getUsers(login)
        client.enqueue(object :Callback<GithubResponse>{
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                if(response.isSuccessful){
                    val githubResponse=response.body()
                    val users=githubResponse?.items?: emptyList()
                    _listUser.postValue(users)
                }
                _isLoading.postValue(false)
            }

            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                _isLoading.postValue(false)

            }
        })
    }
}