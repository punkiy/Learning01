package com.example.submisionawal_fundamental.UI

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.submisionawal_fundamental.data.response.DetailUserResponse

class SelectionPagerAdapter(activity: DetailActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int {
        return 2
    }
    var username:String=""
    override fun createFragment(position: Int): Fragment {
        val fragment = FollowFragment()
        val args = Bundle().apply {
            putInt(FollowFragment.ARG_POSITION, position+ 1)
            putString(FollowFragment.ARG_USERNAME, username)
        }
        fragment.arguments = args
        return fragment
    }
}