package com.example.submisionawal_fundamental.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.submisionawal_fundamental.R
import com.example.submisionawal_fundamental.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    private lateinit var binding:ActivityDetailBinding
    private lateinit var viewModel: MainViewModel
    companion object{
        const val EXTRA_USERNAME="username"
        private val TAB_FOLLOW= arrayOf("Follower","Following")
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username=intent.getStringExtra(EXTRA_USERNAME)
        viewModel=ViewModelProvider(this).get(MainViewModel::class.java)

        viewModel.userDetail.observe(this, Observer {userDetail->
            userDetail?.apply {
                binding.tvnamaProf.text = userDetail.login ?: ""
                binding.rincian.text = userDetail.name ?: ""
                binding.folwer.text = "Followers:${userDetail.followers}"
                binding.folwing.text = "Following:${userDetail.following}"
                Glide.with(this@DetailActivity)
                    .load(userDetail.avatarUrl)
                    .into(binding.imageProf)
            }
        })
        if (username!=null){
            viewModel.getUserDetail(username.toString())
            viewModel.getFollowers(username)
            viewModel.getFollowing(username)
        }



        val viewPager=findViewById<ViewPager2>(R.id.viewPager)
        val selectionPagerAdapter=SelectionPagerAdapter(this)
        viewPager.adapter=selectionPagerAdapter
        val tabs:TabLayout=findViewById(R.id.tabs)
        TabLayoutMediator(tabs,viewPager){
            tab,position->
            tab.text=TAB_FOLLOW[position]
        }.attach()
        supportActionBar?.elevation=0f
    }
}