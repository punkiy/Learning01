package com.example.submisionawal_fundamental.UI

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submisionawal_fundamental.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private val userAdapter = UserAdapter{user->
        val intent=Intent(this@MainActivity,DetailActivity::class.java)
        intent.putExtra("username",user.login)
        startActivity(intent)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.recycleView.layoutManager=LinearLayoutManager(this)
        binding.recycleView.adapter=userAdapter
        viewModel.listUser.observe(this, Observer { user->
            userAdapter.submitList(user)
        })
        viewModel.isLoading.observe(this, Observer { isLoading->
            if(isLoading){
                binding.progressBarr.visibility = View.VISIBLE
            }else{
                binding.progressBarr.visibility=View.GONE
            }
        })
        with(binding){
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                   if(actionId==EditorInfo.IME_ACTION_SEARCH){
                       val searchKeyword=searchView.text.toString()
                       performSearch(searchKeyword)
                       searchView.hide()
                   }
                    return@setOnEditorActionListener false
                }
        }
        viewModel.getUsers("arif")

    }
    private fun performSearch(searchKeyword:String){
        viewModel.getUsers(searchKeyword)
    }


}