package com.example.submisionawal_fundamental.data.retrofit
import com.example.submisionawal_fundamental.data.response.DetailUserResponse
import com.example.submisionawal_fundamental.data.response.GithubResponse
import com.example.submisionawal_fundamental.data.response.ItemsItem
import retrofit2.*
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    fun getUsers(@Query("q") q: String)
    : Call<GithubResponse>

    @GET("users/{username}")
    fun getDetailUser(
        @Path("username")username:String
    ):Call<DetailUserResponse>

    @GET("users/{username}/followers")
    fun getFollowers(@Path("username") username: String): Call<List<ItemsItem>>
    @GET("users/{username}/following")
    fun getFollowing(@Path("username") username: String): Call<List<ItemsItem>>
}

