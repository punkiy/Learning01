package com.example.submisionawal_fundamental.UI

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.submisionawal_fundamental.data.response.DetailUserResponse

class SelectionPagerAdapter(activity: DetailActivity, private val itemsItem: DetailUserResponse?) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int {
        return 2
    }

    override fun createFragment(position: Int): Fragment {
        val fragment = FollowFragment()
        val args = Bundle().apply {
            putInt(FollowFragment.ARG_POSITION, 1)
            putString(FollowFragment.ARG_USERNAME, itemsItem?.login)
        }
        fragment.arguments = args
        return fragment
    }
}