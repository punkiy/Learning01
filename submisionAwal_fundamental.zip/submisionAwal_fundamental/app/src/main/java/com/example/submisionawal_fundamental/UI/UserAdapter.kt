package com.example.submisionawal_fundamental.UI

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submisionawal_fundamental.data.response.ItemsItem
import com.example.submisionawal_fundamental.databinding.ItemBinding


class UserAdapter (private val onItemClick:(ItemsItem)-> Unit): ListAdapter<ItemsItem, UserAdapter.MyHolder>(DIFF_CALLBACK) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val binding= ItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyHolder(binding)
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        val items = getItem(position)
        holder.bind(items)

    }
    class MyHolder(private val binding: ItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ItemsItem){
            binding.tvnames.text=item.login
            Glide.with(binding.profil.context)
                .load(item.avatarUrl)
                .into(binding.profil)
        }
    }
    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ItemsItem>() {
            override fun areItemsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                return oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: ItemsItem, newItem: ItemsItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int, payloads: MutableList<Any>) {
        val items=getItem(position)
        holder.bind(items)
        holder.itemView.setOnClickListener{
            onItemClick.invoke(items)
        }
    }

}

